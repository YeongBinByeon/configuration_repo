package com.example.redisinitconfiguration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedisInitConfigurationApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedisInitConfigurationApplication.class, args);
	}

}
